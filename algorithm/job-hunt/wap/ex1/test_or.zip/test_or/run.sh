#!/bin/bash

for ((i=0; i<200; i++)); do
  #echo "number: "$i
  ./shou2 < "test"$i".txt"
done;
